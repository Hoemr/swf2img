<?php

$strCmd = '"D:\temp\swf2img2.exe" "D:\temp\test.swf" "D:\temp\test.png"';
$strOutput = shell_exec($strCmd);
echo $strOutput;

?>

