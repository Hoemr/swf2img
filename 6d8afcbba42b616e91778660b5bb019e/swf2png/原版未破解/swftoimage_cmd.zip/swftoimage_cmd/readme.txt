Web: http://www.verydoc.com
Email: support@verydoc.com

SWF to Image Converter Command Line examples:

swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test.png"
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test-%04d.png"
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test-%04d.png" -width 800 -height 600
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test-%04d.png" -width -1 -height -1
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test-%04d.png" -timer 1000
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test-%04d.png" -hidewindow
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test-%04d.png" -$ XXXXXXXXXXXXXXXXXX
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test.gif"
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test.tif"
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test.pcx"
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test.bmp"
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test.jpg"
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test.tga"
swf2img.exe -in "D:\temp\test.swf" -out "D:\out\test.mng"
